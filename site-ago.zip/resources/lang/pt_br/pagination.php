<?php

return [
    'previous' => '&laquo; Anterior',
    'next' => 'Próximo &raquo;',
    'showing' => 'Exibindo :first até :last de :total resultados',
];