<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Início')); ?>


        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <section>
                    <header>
                        <h2 class="text-lg font-medium text-gray-900">
                            <?php echo e(__('Atualizar imagens do Slide Principal')); ?>

                        </h2>

                        <p class="mt-1 text-sm text-gray-600">
                            <?php echo e(__('Adicione ou remova imagens')); ?>

                        </p>
                    </header>
                    <form action="<?php echo e(route('add_image')); ?>" class="mt-6 space-y-6" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="imgType" value="main_slide">
                        <div class="mb-3">
                            <input class="form-control" name="image" type="file" id="formFile">
                        </div>
                        <div class="row">
                            <div class="col"><button class="btn btn-primary" type="submit">Upload</button></div>
                            <div class="col">
                                <?php if(session('success_main_slide')): ?>
                                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    <div class="alert alert-success" role="alert" style="color: green;">
                                        <?php echo e(session('success_main_slide')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('error_main_slide')): ?>
                                    <div class="alert alert-danger" role="alert" style="color: red;">
                                        <?php echo e(session('error_main_slide')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    </form>

                    <div class="row space-x-6 p-6 text-gray-900">
                        <?php $__currentLoopData = $imageUrlsMainSlide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card" style="width: 18rem;">
                                <img src="<?php echo e($imageUrl); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    
                                    <form action="<?php echo e(route('remove_image')); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="imgType" value="main_slide">
                                        <input type="hidden" name="image" value="<?php echo e(basename($imageUrl)); ?>">
                                        <button class="btn btn-danger" type="submit">Remover</button>
                                    </form>
                                </div>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </section>
            </div>

            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <section>
                    <header>
                        <h2 class="text-lg font-medium text-gray-900">
                            <?php echo e(__('Atualizar imagens de serviços')); ?>

                        </h2>

                        <p class="mt-1 text-sm text-gray-600">
                            <?php echo e(__('Adicione ou remova imagens')); ?>

                        </p>
                    </header>
                    <form action="<?php echo e(route('add_image')); ?>" class="mt-6 space-y-6" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="imgType" value="services">
                        <div class="mb-3">
                            <input class="form-control" name="image" type="file" id="formFile">
                        </div>
                        <div class="row">
                            <div class="col"><button class="btn btn-primary" type="submit">Upload</button></div>
                            <div class="col">
                                <?php if(session('success_services')): ?>
                                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    <div class="alert alert-success" role="alert" style="color: green;">
                                        <?php echo e(session('success_services')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('error_services')): ?>
                                    <div class="alert alert-danger" role="alert" style="color: red;">
                                        <?php echo e(session('error_services')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    </form>

                    <div class="row space-x-6 p-6 text-gray-900">
                        <?php $__currentLoopData = $imageUrlsServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card" style="width: 18rem;">
                                <img src="<?php echo e($imageUrl); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    
                                    <form action="<?php echo e(route('remove_image')); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="imgType" value="services">
                                        <input type="hidden" name="image" value="<?php echo e(basename($imageUrl)); ?>">
                                        <button class="btn btn-danger" type="submit">Remover</button>
                                    </form>
                                </div>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </section>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\Projetos\Andreone-AGO\site-ago\resources\views/adm/dashboard.blade.php ENDPATH**/ ?>